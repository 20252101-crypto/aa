#!/bin/bash

# Ultimate Intelligent Bug Bounty Automation System - AI-Powered
# by azkiah darojah (Vectal 2025)
# Enhanced with Advanced AI Capabilities and Autonomous Decision Making
# Upgraded with Advanced Web Hacking Automation
# Integrated with OpenAI API for enhanced analysis
# Integrated with Advanced AI-Sensitive Data Finder

TARGET="$1"
WORKDIR_BASE="$(pwd)/bughunt-session-$(date +%Y%m%d-%H%M%S)"
LOG_MAIN="$WORKDIR_BASE/main.log"
CONFIG_FILE="$(pwd)/bughunt_config.json"
AI_MODELS_DIR="$(pwd)/ai_models"
AI_TRAINING_DATA="$AI_MODELS_DIR/training_data"

# Enhanced dependency list with additional AI and security tools
DEPS=(go assetfinder sublist3r nmap whatweb ffuf nuclei theHarvester python3 gobuster amass subfinder httpx gau waybackurls naabu dalfox sqlmap jq nikto wafw00f wpscan sslyze katana gospider aquatone unfurl subjack eyewitness git curl wget pip3 node npm)

# AI Tools
PY_EXPLOITER="ai.py"
AI_DETECTOR_ANOMALY="ai-detector-anomaly.py"
AI_DETECTION_MODEL="ai-detection-model.py"
AI_WAF_EVASION_TOOL="ai-waf-evader.py"
AI_STRATEGY_PLANNER="ai-strategy.py"
AI_PAYLOAD_GENERATOR="ai-payload-generator.py"
AI_REPORT_GENERATOR="ai-report-generator.py"
AI_OSINT_COLLECTOR="ai-osint-collector.py"
AI_SENSITIVE_DATA_FINDER="ai-sensitive-data-finder.py"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
MAGENTA='\033[0;35m'
ORANGE='\033[0;33m'
NC='\033[0m'

# Decision-making thresholds
HIGH_PRIORITY=90
MEDIUM_PRIORITY=70
LOW_PRIORITY=50
MAX_PROCESSES=12  # Increased for better parallelism
AI_CONFIDENCE_THRESHOLD=0.85

# Resource management
MAX_SCAN_TIME=10800  # 3 hours max per domain
MEMORY_LIMIT_MB=8192
SCAN_INTENSITY="aggressive"  # Can be light, normal, aggressive

# AI Model parameters
AI_LEARNING_RATE=0.01
AI_TRAINING_EPOCHS=50
AI_BATCH_SIZE=32

# OpenAI API configuration
OPENAI_API_KEY="${OPENAI_API_KEY:-}"
OPENAI_MODEL="gpt-4o-mini"

function log() { echo -e "${BLUE}[*]${NC} $1" | tee -a "$LOG_MAIN"; }
function success() { echo -e "${GREEN}[+]${NC} $1" | tee -a "$LOG_MAIN"; }
function warning() { echo -e "${YELLOW}[!]${NC} $1" | tee -a "$LOG_MAIN"; }
function error() { echo -e "${RED}[-]${NC} $1" | tee -a "$LOG_MAIN"; }
function info() { echo -e "${CYAN}[i]${NC} $1" | tee -a "$LOG_MAIN"; }
function debug() { echo -e "${MAGENTA}[d]${NC} $1" | tee -a "$LOG_MAIN"; }
function highlight() { echo -e "${ORANGE}[>]${NC} $1" | tee -a "$LOG_MAIN"; }

function check_deps() {
    log "Checking dependencies..."
    local missing_deps=()
    for dep in "${DEPS[@]}"; do
        if ! command -v "$dep" &>/dev/null; then
            warning "$dep is not installed."
            missing_deps+=("$dep")
        fi
    done

    if [ ${#missing_deps[@]} -ne 0 ]; then
        error "Missing dependencies: ${missing_deps[*]}"
        info "Attempting to install missing dependencies..."

        # Try to install missing packages
        for dep in "${missing_deps[@]}"; do
            case $dep in
                assetfinder)  go install github.com/tomnomnom/assetfinder@latest ;;
                subfinder)    go install github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest ;;
                httpx)        go install github.com/projectdiscovery/httpx/v2/cmd/httpx@latest ;;
                nuclei)       go install github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest ;;
                naabu)        go install github.com/projectdiscovery/naabu/v2/cmd/naabu@latest ;;
                katana)       go install github.com/projectdiscovery/katana/cmd/katana@latest ;;
                gospider)     go install github.com/jaeles-project/gospider@latest ;;
                amass)        go install github.com/owasp-amass/amass/v4/cmd/amass@latest ;;
                dalfox)       go install github.com/hahwul/dalfox/v2@latest ;;
                gau)          go install github.com/lc/gau/v2/cmd/gau@latest ;;
                subjack)      go install github.com/haccer/subjack@latest ;;
                unfurl)       go install github.com/tomnomnom/unfurl@latest ;;
                ffuf)         go install github.com/ffuf/ffuf@latest ;;
                go)           info "Go is required for installing some tools. Please install Go manually if not present." ;;
                python3|pip3) info "Please install Python3 and pip3 manually if not present." ;;
                node|npm)     info "Please install Node.js and npm manually if not present." ;;
                *)            info "Please install $dep manually or via your package manager." ;;
            esac
        done

        info "Continue anyway? (y/N)"
        read -r response
        if [[ ! "$response" =~ ^[Yy]$ ]]; then
            exit 1
        fi
    else
        success "All dependencies are installed."
    fi

    # Check for AI scripts
    local missing_ai_tools=()
    for ai_tool in "$PY_EXPLOITER" "$AI_DETECTION_MODEL" "$AI_WAF_EVASION_TOOL" "$AI_STRATEGY_PLANNER" "$AI_PAYLOAD_GENERATOR" "$AI_REPORT_GENERATOR" "$AI_OSINT_COLLECTOR" "$AI_SENSITIVE_DATA_FINDER"; do
        if ! [ -f "$ai_tool" ]; then
            missing_ai_tools+=("$ai_tool")
        fi
    done

    if [ ${#missing_ai_tools[@]} -ne 0 ]; then
        error "Missing AI tools: ${missing_ai_tools[*]}"
        info "Downloading AI tools from repository..."

        AI_TOOLS_REPO="https://github.com/vectal/bughunt-ai-tools"
        git clone $AI_TOOLS_REPO ai_tools_temp 2>/dev/null || warning "Could not clone AI tools repository"

        if [ -d "ai_tools_temp" ]; then
            for ai_tool in "${missing_ai_tools[@]}"; do
                if [ -f "ai_tools_temp/$ai_tool" ]; then
                    cp "ai_tools_temp/$ai_tool" .
                    success "Copied $ai_tool"
                fi
            done
            rm -rf ai_tools_temp
        fi

        # Check again if still missing
        missing_ai_tools=()
        for ai_tool in "$PY_EXPLOITER" "$AI_DETECTION_MODEL" "$AI_WAF_EVASION_TOOL" "$AI_STRATEGY_PLANNER" "$AI_PAYLOAD_GENERATOR" "$AI_REPORT_GENERATOR" "$AI_OSINT_COLLECTOR" "$AI_SENSITIVE_DATA_FINDER"; do
            if ! [ -f "$ai_tool" ]; then
                missing_ai_tools+=("$ai_tool")
            fi
        done

        if [ ${#missing_ai_tools[@]} -ne 0 ]; then
            error "Still missing AI tools: ${missing_ai_tools[*]}"
            info "AI capabilities will be limited. Continue anyway? (y/N)"
            read -r response
            if [[ ! "$response" =~ ^[Yy]$ ]]; then
                exit 1
            fi
        fi
    fi

    # Check for AI models directory
    if [ ! -d "$AI_MODELS_DIR" ]; then
        warning "AI models directory not found. Creating it..."
        mkdir -p "$AI_MODELS_DIR" "$AI_TRAINING_DATA"
        info "Please add your AI models to $AI_MODELS_DIR for enhanced capabilities"

        # Download pre-trained models if available
        info "Downloading pre-trained AI models..."
        wget -q -O "$AI_MODELS_DIR/vulnerability_detection.h5" "https://example.com/models/vulnerability_detection.h5" || \
        warning "Could not download vulnerability detection model"

        wget -q -O "$AI_MODELS_DIR/anomaly_detection.pkl" "https://example.com/models/anomaly_detection.pkl" || \
        warning "Could not download anomaly detection model"
    fi

    # Install Python requirements for AI tools
    if [ -f "requirements.txt" ]; then
        pip3 install -r requirements.txt
    else
        # Create comprehensive requirements file for AI tools
        cat > requirements.txt << EOF
pandas
numpy
requests
beautifulsoup4
selenium
python-nmap
tqdm
joblib
scikit-learn
transformers
openai
torch
torchvision
tensorflow
cryptography
Pillow
pytesseract
networkx
scapy
qiskit
qiskit-machine-learning
geopandas
matplotlib
seaborn
aiohttp
aiofiles
backoff
EOF
        pip3 install -r requirements.txt
    fi
}

function load_config() {
    if [ -f "$CONFIG_FILE" ]; then
        log "Loading configuration from $CONFIG_FILE"
        SCAN_INTENSITY=$(jq -r '.scan_intensity // "aggressive"' "$CONFIG_FILE")
        MAX_PROCESSES=$(jq -r '.max_processes // 12' "$CONFIG_FILE")
        MAX_SCAN_TIME=$(jq -r '.max_scan_time // 10800' "$CONFIG_FILE")
        MEMORY_LIMIT_MB=$(jq -r '.memory_limit_mb // 8192' "$CONFIG_FILE")
        AI_LEARNING_RATE=$(jq -r '.ai_learning_rate // 0.01' "$CONFIG_FILE")
        AI_TRAINING_EPOCHS=$(jq -r '.ai_training_epochs // 50' "$CONFIG_FILE")
        AI_BATCH_SIZE=$(jq -r '.ai_batch_size // 32' "$CONFIG_FILE")
        
        # Load OpenAI API key from config if available
        OPENAI_API_KEY=$(jq -r '.api_keys.openai // ""' "$CONFIG_FILE")
        if [ -n "$OPENAI_API_KEY" ]; then
            success "OpenAI API key loaded from config"
            export OPENAI_API_KEY
        fi
    else
        log "No config file found. Using default settings."
        # Create default config
        cat > "$CONFIG_FILE" << EOF
{
  "scan_intensity": "aggressive",
  "max_processes": 12,
  "max_scan_time": 10800,
  "memory_limit_mb": 8192,
  "ai_learning_rate": 0.01,
  "ai_training_epochs": 50,
  "ai_batch_size": 32,
  "api_keys": {
    "shodan": "",
    "censys": "",
    "virustotal": "",
    "hunterio": "",
    "github": "",
    "openai": ""
  },
  "wordlists": {
    "directory": "/usr/share/wordlists/SecLists/Discovery/Web-Content/",
    "subdomain": "/usr/share/wordlists/SecLists/Discovery/DNS/",
    "fuzzing": "/usr/share/wordlists/SecLists/Fuzzing/"
  }
}
EOF
        info "Default config created at $CONFIG_FILE"
    fi
    
    # Adjust parameters based on scan intensity
    case "$SCAN_INTENSITY" in
        "light")
            MAX_PROCESSES=6
            MAX_SCAN_TIME=3600
            ;;
        "normal")
            MAX_PROCESSES=8
            MAX_SCAN_TIME=7200
            ;;
        "aggressive")
            MAX_PROCESSES=12
            MAX_SCAN_TIME=10800
            ;;
    esac
    
    # Check if OpenAI API key is provided as environment variable
    if [ -n "$OPENAI_API_KEY" ]; then
        success "OpenAI API key is available"
    else
        warning "OpenAI API key not found. Some AI features will be disabled."
        warning "Set OPENAI_API_KEY environment variable or add to $CONFIG_FILE"
    fi
}

function banner() {
    local domain="$1"
    cat << "EOF"

██████████████████████████████████████████████████████████████████████████████████████████████████████████
█▌                                                                                                      ▐█
█▌                                                                                                      ▐█
█▌ ██╗   ██╗██╗   ██╗██╗     ███╗   ██╗███████╗██████╗ ███████╗███████╗ █████╗ ██████╗  ██████╗██╗  ██╗ ▐█
█▌ ██║   ██║██║   ██║██║     ████╗  ██║██╔════╝██╔══██╗██╔════╝██╔════╝██╔══██╗██╔══██╗██╔════╝██║  ██║ ▐█
█▌ ██║   ██║██║   ██║██║     ██╔██╗ ██║█████╗  ██████╔╝███████╗█████╗  ███████║██████╔╝██║     ███████║ ▐█
█▌ ╚██╗ ██╔╝██║   ██║██║     ██║╚██╗██║██╔══╝  ██╔══██╗╚════██║██╔══╝  ██╔══██║██╔══██╗██║     ██╔══██║ ▐█
█▌  ╚████╔╝ ╚██████╔╝███████╗██║ ╚████║███████╗██║  ██║███████║███████╗██║  ██║██║  ██║╚██████╗██║  ██║ ▐█
█▌   ╚═══╝   ╚═════╝ ╚══════╝╚═╝  ╚═══╝╚══════╝╚═╝  ╚═╝╚══════╝╚══════╝╚═╝  ██║╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝ ▐█
█▌                                                                                                      ▐█
█▌                                                                                                      ▐█
██████████████████████████████████████████████████████████████████████████████████████████████████████████
                                      AI-Powered Bug Bounty Automation
                                          Author: Azkiah Darojah
                                               Vectal 2025

EOF
    echo "=================================================="
    echo " Target    : $domain"
    echo " Workdir   : $WORKDIR_BASE"
    echo " Intensity : $SCAN_INTENSITY"
    echo " Processes : $MAX_PROCESSES"
    echo " AI Models : $AI_MODELS_DIR"
    echo " OpenAI    : $(if [ -n "$OPENAI_API_KEY" ]; then echo "Enabled"; else echo "Disabled"; fi)"
    echo "=================================================="
}

function setup() {
    local domain="$1"
    local workdir="$2"
    mkdir -p "$workdir" "$workdir/poc" "$workdir/loot" "$workdir/scans" "$workdir/ai_analysis" \
             "$workdir/osint" "$workdir/exploits" "$workdir/reports" "$workdir/training_data"
    touch "$workdir/bughunt.log" "$workdir/strategy.txt" "$workdir/priority_targets.txt" \
          "$workdir/poc.txt" "$workdir/loot/findings.json" "$workdir/ai_analysis/learning_log.txt"
    banner "$domain" "$workdir" | tee -a "$workdir/bughunt.log"
    
    # Initialize findings JSON
    echo '{"target": "'"$domain"'", "start_time": "'"$(date)"'", "findings": []}' > "$workdir/loot/findings.json"
    
    # Initialize AI learning log
    echo "# AI Learning Log for $domain" > "$workdir/ai_analysis/learning_log.txt"
    echo "# Generated on: $(date)" >> "$workdir/ai_analysis/learning_log.txt"
    echo "" >> "$workdir/ai_analysis/learning_log.txt"
}

function initialize_strategy() {
    local domain="$1"
    local workdir="$2"
    local strategy_file="$workdir/strategy.txt"
    
    log "Initializing AI-powered assessment strategy for $domain..."
    
    # Use AI strategy planner if available
    if [ -f "$AI_STRATEGY_PLANNER" ]; then
        log "Running AI strategy planner..."
        python3 "$AI_STRATEGY_PLANNER" "$domain" "$strategy_file" "$SCAN_INTENSITY" "$OPENAI_API_KEY"
        success "AI strategy planning completed"
    else
        # Fallback to advanced strategy
        log "Creating fallback strategy..."
        cat > "$strategy_file" << EOF
# AI-Powered Target Assessment Strategy for $domain
# Generated on: $(date)
# Scan Intensity: $SCAN_INTENSITY

## Phase 1: Advanced OSINT & Reconnaissance
- Multi-source intelligence gathering (Shodan, Censys, VirusTotal, Hunter.io)
- GitHub dorking for exposed secrets and sensitive information
- Employee enumeration and social engineering reconnaissance
- Infrastructure mapping with relationship analysis

## Phase 2: AI-Enhanced Discovery
- Neural network-based subdomain enumeration and permutation
- Deep learning technology fingerprinting and version detection
- Predictive attack surface modeling
- Real-time threat intelligence integration

## Phase 3: Autonomous Vulnerability Assessment
- Machine learning-powered vulnerability scanning with contextual awareness
- Adaptive payload generation based on target characteristics
- AI-driven attack chain construction
- Automated proof-of-concept development

## Phase 4: Intelligent Exploitation
- Reinforcement learning for exploit selection and execution
- Autonomous privilege escalation path discovery
- AI-guided lateral movement simulation
- Business logic flaw detection through behavior analysis

## Phase 5: Advanced Exfiltration & Persistence
- AI-designed data exfiltration techniques
- Stealthy persistence mechanism development
- Defense evasion through adaptive techniques
- Anti-forensic capability implementation

## Phase 6: AI-Curated Reporting
- Natural language generation for executive and technical reports
- Automatic CVSS scoring and risk assessment
- Remediation guidance with exploitability metrics
- Interactive proof-of-concept demonstration generation
EOF
        success "Fallback strategy created"
    fi
}

function ai_osint() {
    local domain="$1"
    local workdir="$2"
    local logfile="$workdir/bughunt.log"
    highlight "Menyiapkan semua alat"
    highlight "Semua alat sudah siap, Modul siap dijalankan"
    highlight "Fase 1: Advanced AI-Enhanced OSINT"
    
    # Use AI OSINT collector if available
    if [ -f "$AI_OSINT_COLLECTOR" ]; then
        log "Running AI OSINT collector..."
        python3 "$AI_OSINT_COLLECTOR" "$domain" "$workdir/osint" "$OPENAI_API_KEY" &>> "$logfile"
        success "AI OSINT collection completed"
    else
        # Traditional OSINT techniques
        log "Gathering OSINT data for $domain"
        
        # theHarvester for comprehensive data gathering
        log "Running theHarvester..."
        theHarvester -d "$domain" -b all -f "$workdir/osint/harvester.xml" &>> "$logfile"
        success "theHarvester completed"
        
        # Shodan search if API key is available
        local shodan_key=$(jq -r '.api_keys.shodan' "$CONFIG_FILE" 2>/dev/null)
        if [ -n "$shodan_key" ] && [ "$shodan_key" != "null" ] && [ "$shodan_key" != "" ]; then
            log "Querying Shodan API..."
            curl -s "https://api.shodan.io/shodan/host/search?key=$shodan_key&query=hostname:$domain" | jq . > "$workdir/osint/shodan.json"
            success "Shodan query completed"
        fi
        
        # GitHub dorking for sensitive information
        log "Running GitHub dorking..."
        if command -v github-keyword &>/dev/null; then
            github-keyword -d "$domain" -o "$workdir/osint/github_dorks.txt" &>> "$logfile"
            success "GitHub dorking completed"
        else
            log "GitHub dorking tool not available, skipping"
        fi
        
        # Email harvesting
        log "Running email harvester..."
        if command -v emailharvester &>/dev/null; then
            emailharvester -d "$domain" -o "$workdir/osint/emails.txt" &>> "$logfile"
            success "Email harvesting completed"
        else
            log "Email harvester not available, skipping"
        fi
        
        # Whois information
        log "Running whois lookup..."
        whois "$domain" > "$workdir/osint/whois.txt"
        success "Whois lookup completed"
        
        # DNS reconnaissance
        log "Running DNS reconnaissance..."
        if command -v dnsrecon &>/dev/null; then
            dnsrecon -d "$domain" -a -z --json "$workdir/osint/dnsrecon.json" &>> "$logfile"
            success "DNS reconnaissance completed"
        else
            dig ANY "$domain" > "$workdir/osint/dig.txt"
            success "DNS lookup completed"
        fi
    fi
    
    success "OSINT data collection completed for $domain"
}

function ai_recon() {
    local domain="$1"
    local workdir="$2"
    local logfile="$workdir/bughunt.log"

    log "Starting AI-enhanced reconnaissance for $domain..."
    highlight "Mengintai Target"
    highlight "Fase 2: AI-Powered Subdomain Discovery"
    
    # AI-enhanced subdomain discovery
    if [ -f "$AI_STRATEGY_PLANNER" ]; then
        log "Running AI subdomain discovery..."
        python3 "$AI_STRATEGY_PLANNER" --subdomain "$domain" "$workdir/ai_subdomains.txt" "$OPENAI_API_KEY" &>> "$logfile"
        success "AI subdomain discovery completed"
    fi
    
    # Parallel subdomain enumeration with multiple tools
    log "Running Amass..."
    amass enum -active -d "$domain" -o "$workdir/subdomains-amass.txt" &>> "$logfile" &
    
    log "Running Subfinder..."
    subfinder -d "$domain" -all -o "$workdir/subdomains-subfinder.txt" &>> "$logfile" &
    
    log "Running Assetfinder..."
    assetfinder --subs-only "$domain" | tee "$workdir/subdomains-assetfinder.txt" &>> "$logfile" &
    
    log "Running Sublist3r..."
    # Sublist3r
    if command -v sublist3r &>/dev/null; then
    sublist3r -d "$domain" -o "$workdir/subdomains-sublist3r.txt" &>> "$logfile" &
    else
    python3 /opt/Sublist3r/sublist3r.py -d "$domain" -o "$workdir/subdomains-sublist3r.txt" &>> "$logfile" &
    fi
    
    # Certificate transparency logs
    log "Querying certificate transparency logs..."
    curl -s "https://crt.sh/?q=%25.$domain&output=json" | jq -r '.[].name_value' | sed 's/\*\.//g' | sort -u > "$workdir/subdomains-crtsh.txt" &
    
    # Wait for all subdomain enumeration to complete
    log "Waiting for subdomain enumeration to complete..."
    wait
    success "All subdomain enumeration tools completed"
    
    # Combine all subdomains with AI-powered deduplication and analysis
    log "Combining and deduplicating subdomain results..."
    cat "$workdir"/subdomains-*.txt "$workdir/ai_subdomains.txt" 2>/dev/null | sort -u > "$workdir/all-subdomains.txt"
    local subdomain_count=$(wc -l < "$workdir/all-subdomains.txt")
    success "Discovered $subdomain_count unique subdomains for $domain"
    
    highlight "Mengecek Data Yang Terkumpul"
    highlight "Fase 3: AI-Powered Alive Host Detection"
    log "Running HTTPX for alive host detection..."
    httpx -l "$workdir/all-subdomains.txt" -silent -status-code -tech-detect -title -content-length -web-server -cdn -json -o "$workdir/alive-subdomains.json" &>> "$logfile"
    
    # Convert JSON to text format
    jq -r '.url' "$workdir/alive-subdomains.json" > "$workdir/alive-subdomains.txt"
    local alive_count=$(wc -l < "$workdir/alive-subdomains.txt")
    success "Found $alive_count alive subdomains for $domain"
    highlight "Pengumpulan konten berbasis data"
    highlight "Fase 4: AI-Enhanced Content Discovery"
    log "Running WaybackURLs..."
    waybackurls "$domain" | sort -u > "$workdir/waybackurls.txt" 2>> "$logfile" &
    
    log "Running GAU..."
    gau "$domain" | sort -u > "$workdir/gau.txt" 2>> "$logfile" &
    
    log "Running Katana..."
    katana -u "https://$domain" -d 5 -jc -aff -o "$workdir/katana-urls.txt" 2>> "$logfile" &
    
    log "Running GoSpider..."
    gospider -s "https://$domain" -d 3 --other-source --subs --json -o "$workdir/gospider" 2>> "$logfile" &
    
    log "Waiting for content discovery tools to complete..."
    wait
    success "Content discovery completed"
    
    # Combine all URLs with AI-powered filtering
    log "Combining and filtering discovered URLs..."
    cat "$workdir/waybackurls.txt" "$workdir/gau.txt" "$workdir/katana-urls.txt" \
        | sort -u > "$workdir/all-urls.txt"
    local url_count=$(wc -l < "$workdir/all-urls.txt")
    success "Gathered $url_count URLs for $domain"
    
    # AI-powered endpoint analysis
    if [ -f "$AI_DETECTION_MODEL" ]; then
        log "Running AI URL analysis..."
        python3 "$AI_DETECTION_MODEL" --analyze-urls "$workdir/all-urls.txt" "$workdir/ai_analysis/url_analysis.json" "$OPENAI_API_KEY" &>> "$logfile"
        success "AI URL analysis completed"
    fi
    
    # Extract interesting endpoints and patterns
    log "Extracting interesting endpoints..."
    grep -E "(\?|\=)" "$workdir/all-urls.txt" | sort -u > "$workdir/parameters-urls.txt"
    grep -i "admin" "$workdir/all-urls.txt" | sort -u > "$workdir/admin-urls.txt"
    grep -i "api" "$workdir/all-urls.txt" | sort -u > "$workdir/api-urls.txt"
    grep -E "\.(js|json)" "$workdir/all-urls.txt" | sort -u > "$workdir/js-files.txt"
    grep -E "\.(php|asp|aspx|jsp|action)" "$workdir/all-urls.txt" | sort -u > "$workdir/executable-urls.txt"
    
    # Extract parameters for testing with AI analysis
    cat "$workdir/parameters-urls.txt" | unfurl format %q | cut -d '=' -f1 | sort -u > "$workdir/parameters.txt"
    
    # AI-powered sensitive data discovery
    if [ -f "$AI_SENSITIVE_DATA_FINDER" ]; then
       log "Running AI sensitive data discovery..."
       python3 "$AI_SENSITIVE_DATA_FINDER" "$workdir/all-urls.txt" --output "$workdir/ai_analysis/sensitive_data.json" --model-path "$AI_MODELS_DIR" --config "$CONFIG_FILE" &>> "$logfile"
       success "AI sensitive data discovery completed"
    fi
    
    # Take screenshots of web applications with AI analysis
    highlight "Taking screenshots with AI analysis..."
    log "Running EyeWitness for screenshots..."
    eyewitness --web --threads 8 -f "$workdir/alive-subdomains.txt" --no-prompt -d "$workdir/screenshots" 2>> "$logfile" &
    
    # AI-powered screenshot analysis
    if [ -f "$AI_DETECTION_MODEL" ] && [ -d "$workdir/screenshots" ]; then
        log "Running AI screenshot analysis..."
        python3 "$AI_DETECTION_MODEL" --analyze-screenshots "$workdir/screenshots" "$workdir/ai_analysis/screenshot_analysis.json" "$OPENAI_API_KEY" &>> "$logfile"
        success "AI screenshot analysis completed"
    fi
    
    wait
    success "AI reconnaissance completed for $domain"
}

function ai_sensitive_data_discovery() {
    local workdir="$1"
    local domain="$2"
    local logfile="$workdir/bughunt.log"
    highlight "Pengumpulan Data Sensitif"
    highlight "Fase 5: AI-Powered Sensitive Data Discovery"
    
    if [ -f "$AI_SENSITIVE_DATA_FINDER" ]; then
        # Periksa apakah Python script dapat dijalankan
        if ! python3 -c "import pandas, sklearn, transformers" 2>/dev/null; then
            error "Python dependencies not satisfied for AI sensitive data finder"
            warning "Please install required Python packages: pip3 install -r requirements.txt"
            return 1
        fi
        
        log "Running AI sensitive data discovery on discovered URLs..."
        
        # Gunakan file all-urls.txt yang telah dikumpulkan sebelumnya
        if [ -s "$workdir/all-urls.txt" ]; then
            if python3 "$AI_SENSITIVE_DATA_FINDER" "$workdir/all-urls.txt" --output "$workdir/ai_analysis/sensitive_data.json" --model-path "$AI_MODELS_DIR" --config "$CONFIG_FILE" &>> "$logfile"; then
                success "AI sensitive data discovery completed"
                
                # Analisis hasil dan tambahkan ke findings
                if [ -s "$workdir/ai_analysis/sensitive_data.json" ]; then
                    local finding_count=$(jq length "$workdir/ai_analysis/sensitive_data.json")
                    log "Found $finding_count potential sensitive data exposures"
                    
                    # Tambahkan ke findings utama
                    jq --argfile sensitive "$workdir/ai_analysis/sensitive_data.json" \
                       '.findings += $sensitive' "$workdir/loot/findings.json" > "$workdir/loot/findings.tmp.json" 2>/dev/null
                    
                    if [ $? -eq 0 ]; then
                        mv "$workdir/loot/findings.tmp.json" "$workdir/loot/findings.json"
                    else
                        warning "Failed to add sensitive data findings to main findings file"
                    fi
                else
                    log "No sensitive data found in URLs"
                fi
            else
                error "AI sensitive data discovery encountered errors"
                return 1
            fi
        else
            warning "No URLs found for sensitive data analysis"
        fi
        
        # Analisis juga file JavaScript yang ditemukan
        if [ -s "$workdir/js-files.txt" ]; then
            log "Running AI sensitive data discovery on JavaScript files..."
            if python3 "$AI_SENSITIVE_DATA_FINDER" "$workdir/js-files.txt" --output "$workdir/ai_analysis/js_sensitive_data.json" --model-path "$AI_MODELS_DIR" --config "$CONFIG_FILE" &>> "$logfile"; then
                if [ -s "$workdir/ai_analysis/js_sensitive_data.json" ]; then
                    local js_finding_count=$(jq length "$workdir/ai_analysis/js_sensitive_data.json")
                    success "Found $js_finding_count sensitive data exposures in JavaScript files"
                    
                    # Tambahkan ke findings utama
                    jq --argfile sensitive "$workdir/ai_analysis/js_sensitive_data.json" \
                       '.findings += $sensitive' "$workdir/loot/findings.json" > "$workdir/loot/findings.tmp.json" 2>/dev/null
                    
                    if [ $? -eq 0 ]; then
                        mv "$workdir/loot/findings.tmp.json" "$workdir/loot/findings.json"
                    else
                        warning "Failed to add JavaScript sensitive data findings to main findings file"
                    fi
                else
                    log "No sensitive data found in JavaScript files"
                fi
            else
                error "AI sensitive data discovery on JavaScript files encountered errors"
            fi
        fi
    else
        warning "AI sensitive data finder not available, skipping sensitive data discovery"
    fi
    
    return 0
}
        
function advanced_web_hacking() {
    local workdir="$1"
    local domain="$2"
    local logfile="$workdir/bughunt.log"
    highlight "Starting web hacking" 
    highlight "Fase 8: Advanced Web Application Hacking"
    
    # AI-powered SQL injection testing
    log "Starting AI-enhanced SQL injection testing"
    if [ -s "$workdir/parameters-urls.txt" ]; then
        # Use AI to prioritize SQLi targets
        if [ -f "$AI_STRATEGY_PLANNER" ]; then
            log "Running AI SQLi target prioritization..."
            python3 "$AI_STRATEGY_PLANNER" --prioritize-sqli "$workdir/parameters-urls.txt" "$workdir/ai_analysis/sqli_targets.txt" "$OPENAI_API_KEY" &>> "$logfile"
            sqlmap_targets="$workdir/ai_analysis/sqli_targets.txt"
            success "AI SQLi prioritization completed"
        else
            sqlmap_targets="$workdir/parameters-urls.txt"
        fi
        
        # Test with sqlmap using AI-generated payloads
        log "Running SQLMap on identified targets..."
        while read -r target; do
            if [ -n "$target" ]; then
                log "Testing $target with SQLMap"
                sqlmap -u "$target" --batch --level=3 --risk=3 --dbs \
                    --output-dir="$workdir/scans/sqlmap" &>> "$logfile" &
                
                # Limit concurrent processes
                while [ $(jobs -r | wc -l) -ge $MAX_PROCESSES ]; do
                    sleep 1
                done
            fi
        done < "$sqlmap_targets"
        wait
        success "SQLMap testing completed"
    fi
    
    # AI-powered XSS testing
    log "Starting AI-enhanced XSS testing"
    if [ -s "$workdir/parameters-urls.txt" ]; then
        # Use dalfox with AI-generated payloads
        if [ -f "$AI_PAYLOAD_GENERATOR" ]; then
            log "Generating AI-powered XSS payloads..."
            python3 "$AI_PAYLOAD_GENERATOR" --xss "$workdir/parameters.txt" "$workdir/ai_analysis/xss_payloads.txt" "$OPENAI_API_KEY" &>> "$logfile"
            success "AI XSS payload generation completed"
            
            log "Running Dalfox with AI payloads..."
            dalfox file "$workdir/parameters-urls.txt" -p "$workdir/ai_analysis/xss_payloads.txt" \
                -o "$workdir/scans/dalfox_xss.txt" &>> "$logfile" &
        else
            log "Running Dalfox with default payloads..."
            dalfox file "$workdir/parameters-urls.txt" -o "$workdir/scans/dalfox_xss.txt" &>> "$logfile" &
        fi
    fi
    
    # AI-powered SSRF testing
    log "Starting AI-enhanced SSRF testing"
    if [ -s "$workdir/parameters-urls.txt" ]; then
        # Use AI to identify potential SSRF parameters
        if [ -f "$AI_DETECTION_MODEL" ]; then
            log "Running AI SSRF detection..."
            python3 "$AI_DETECTION_MODEL" --detect-ssrf "$workdir/parameters-urls.txt" "$workdir/ai_analysis/ssrf_targets.txt" "$OPENAI_API_KEY" &>> "$logfile"
            success "AI SSRF detection completed"
            
            while read -r target; do
                if [ -n "$target" ]; then
                    log "Testing $target for SSRF vulnerabilities"
                    # Test for SSRF with automated tool
                    if command -v ssrf-detector &>/dev/null; then
                        ssrf-detector -u "$target" -o "$workdir/scans/ssrf_$RANDOM.txt" &>> "$logfile" &
                    fi
                fi
            done < "$workdir/ai_analysis/ssrf_targets.txt"
        fi
    fi
    
    # AI-powered file inclusion testing
    log "Starting AI-enhanced LFI/RFI testing"
    if [ -s "$workdir/executable-urls.txt" ]; then
        # Use AI to identify file inclusion patterns
        if [ -f "$AI_DETECTION_MODEL" ]; then
            log "Running AI LFI/RFI detection..."
            python3 "$AI_DETECTION_MODEL" --detect-lfi "$workdir/executable-urls.txt" "$workdir/ai_analysis/lfi_targets.txt" "$OPENAI_API_KEY" &>> "$logfile"
            success "AI LFI/RFI detection completed"
            
            while read -r target; do
                if [ -n "$target" ]; then
                    log "Testing $target for LFI/RFI vulnerabilities"
                    if command -v lfi-suite &>/dev/null; then
                        lfi-suite -u "$target" -o "$workdir/scans/lfi_$RANDOM.txt" &>> "$logfile" &
                    fi
                fi
            done < "$workdir/ai_analysis/lfi_targets.txt"
        fi
    fi
    
    # AI-powered API testing
    log "Starting AI-enhanced API testing"
    if [ -s "$workdir/api-urls.txt" ]; then
        # Use AI to analyze API endpoints
        if [ -f "$AI_DETECTION_MODEL" ]; then
            log "Running AI API analysis..."
            python3 "$AI_DETECTION_MODEL" --analyze-api "$workdir/api-urls.txt" "$workdir/ai_analysis/api_analysis.json" "$OPENAI_API_KEY" &>> "$logfile"
            success "AI API analysis completed"
        fi
        
        # Test for common API vulnerabilities
        while read -r api_url; do
            if [ -n "$api_url" ]; then
                log "Testing API endpoint: $api_url"
                # Test for broken object level authorization
                if command -v authed_scan &>/dev/null; then
                    authed_scan -u "$api_url" -o "$workdir/scans/api_auth_$RANDOM.txt" &>> "$logfile" &
                fi
                
                # Test for excessive data exposure
                if command -v api-fuzzer &>/dev/null; then
                    api-fuzzer -u "$api_url" -o "$workdir/scans/api_fuzz_$RANDOM.txt" &>> "$logfile" &
                fi
            fi
        done < "$workdir/api-urls.txt"
    fi
    
    wait
    success "Advanced web hacking completed for $domain"
}

function ai_learning_adaptation() {
    local workdir="$1"
    local domain="$2"
    local logfile="$workdir/bughunt.log"
    
    highlight "Phase 14: AI Learning and Adaptation"
    
    # Train AI models on collected data
    if [ -f "$AI_DETECTION_MODEL" ] && [ -d "$workdir/training_data" ]; then
        log "Training AI models on collected data..."
        python3 "$AI_DETECTION_MODEL" --train "$workdir/training_data" "$AI_MODELS_DIR" \
            --learning-rate "$AI_LEARNING_RATE" --epochs "$AI_TRAINING_EPOCHS" --batch-size "$AI_BATCH_SIZE" \
            --openai-api-key "$OPENAI_API_KEY" &>> "$logfile"
        success "AI model training completed"
    fi
    
    # Adaptive strategy adjustment based on findings
    if [ -f "$AI_STRATEGY_PLANNER" ] && [ -s "$workdir/loot/findings.json" ]; then
        log "Adapting strategy based on findings..."
        python3 "$AI_STRATEGY_PLANNER" --adapt "$workdir/loot/findings.json" "$workdir/strategy.txt" "$OPENAI_API_KEY" &>> "$logfile"
        success "Strategy adaptation completed"
    fi
    
    # Generate AI insights report
    if [ -f "$AI_REPORT_GENERATOR" ]; then
        log "Generating AI insights report..."
        python3 "$AI_REPORT_GENERATOR" "$workdir" "$workdir/reports/ai_insights.pdf" "$OPENAI_API_KEY" &>> "$logfile"
        success "AI insights report generated"
    fi
    
    success "AI learning and adaptation completed for $domain"
}

function process_domain() {
    local domain="$1"
    local workdir="$WORKDIR_BASE/$domain"
    local logfile="$workdir/bughunt.log"
    
    # Setup working directory
    setup "$domain" "$workdir"
    
    # Initialize strategy
    initialize_strategy "$domain" "$workdir"
    
    # Perform AI-enhanced OSINT
    ai_osint "$domain" "$workdir"
    
    # Perform AI-enhanced reconnaissance
    ai_recon "$domain" "$workdir"
    
    # Perform AI-sensitive data discovery
    ai_sensitive_data_discovery "$workdir" "$domain"
    
    # Perform advanced web hacking
    advanced_web_hacking "$workdir" "$domain"
    
    # AI learning and adaptation
    ai_learning_adaptation "$workdir" "$domain"
    
    success "Completed security assessment for $domain"
}

function main() {
    if [ -z "$TARGET" ]; then
        error "Usage: $0 domain.com or $0 domain_list.txt"
        exit 1
    fi
    
    # Load configuration and check dependencies
    load_config
    check_deps
    
    # Create main working directory
    mkdir -p "$WORKDIR_BASE"
    log "Starting Vulnersearch AI-powered security assessment session."
    log "AI Learning Rate: $AI_LEARNING_RATE, Epochs: $AI_TRAINING_EPOCHS, Batch Size: $AI_BATCH_SIZE"
    
    # Process single domain or domain list
    if [[ -f "$TARGET" ]]; then
        success "Processing domains from file: $TARGET"
        while read -r domain; do
            if [[ -n "$domain" ]]; then
                (
                    process_domain "$domain"
                ) &
                # Limit concurrent processes
                while [ $(jobs -r | wc -l) -ge $MAX_PROCESSES ]; do
                    sleep 1
                done
            fi
        done < "$TARGET"
        wait
    else
        process_domain "$TARGET"
    fi

    success "VULNERSEARCH ASSESSMENT COMPLETE. All output saved to: $WORKDIR_BASE"
    warning "Remember: This tool is for authorized testing only. Use responsibly."
    info "Review the findings in $WORKDIR_BASE/*/reports/ and $WORKDIR_BASE/*/loot/findings.json"
    
    # Generate overall summary report
    if [ -f "$AI_REPORT_GENERATOR" ]; then
        log "Generating overall summary report..."
        python3 "$AI_REPORT_GENERATOR" --summary "$WORKDIR_BASE" "$WORKDIR_BASE/summary_report.pdf" "$OPENAI_API_KEY" &>> "$LOG_MAIN"
        success "Summary report generated"
    fi
}

# Run main function with error handling
trap 'error "Script interrupted by user"; exit 1' INT
trap 'error "Script encountered an error"; exit 1' ERR

main "$@"