#!/usr/bin/env python3
import json
import re
import sys

def main(poc_file, workdir, domain):
    findings = []
    with open(poc_file, 'r') as f:
        content = f.read()

    # Extract findings using simple pattern matching
    critical_findings = re.findall(r'(?i)(critical.*?)(?=##|\Z)', content, re.DOTALL)
    high_findings = re.findall(r'(?i)(high.*?)(?=##|\Z)', content, re.DOTALL)

    for finding in critical_findings + high_findings:
        findings.append({
            'severity': 'Critical' if finding in critical_findings else 'High',
            'description': finding.strip(),
            'target': domain
        })

    # Update findings JSON
    with open(f'{workdir}/loot/findings.json', 'w') as f:
        json.dump({'target': domain, 'findings': findings}, indent=2)

if __name__ == "__main__":
    if len(sys.argv) != 4:
        print("Usage: python3 generate_findings_json.py <poc_file> <workdir> <domain>")
        sys.exit(1)
    
    main(sys.argv[1], sys.argv[2], sys.argv[3])
