#!/usr/bin/env python3
"""
AI-Powered Security Assessment Report Generator
Version: 2.0
Author: Azkiah Darojah (Vectal 2025)
Description: Generates comprehensive security assessment reports with AI analysis
"""

import json
import os
import sys
import argparse
import datetime
import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns
from fpdf import FPDF
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import plotly.express as px
from wordcloud import WordCloud
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.cluster import KMeans
import pandas as pd
from textblob import TextBlob
import warnings
warnings.filterwarnings('ignore')

class AIReportGenerator:
    def __init__(self, workdir, output_file=None):
        self.workdir = workdir
        self.output_file = output_file or os.path.join(workdir, "reports", "security_assessment_report.pdf")
        self.findings_file = os.path.join(workdir, "loot", "findings.json")
        self.strategy_file = os.path.join(workdir, "strategy.txt")
        self.poc_file = os.path.join(workdir, "poc.txt")
        self.ai_analysis_dir = os.path.join(workdir, "ai_analysis")
        
        # Create reports directory if it doesn't exist
        os.makedirs(os.path.dirname(self.output_file), exist_ok=True)
        
        # Load data
        self.findings = self.load_findings()
        self.strategy = self.load_strategy()
        self.poc_data = self.load_poc_data()
        self.ai_analysis = self.load_ai_analysis()
        
        # Initialize PDF
        self.pdf = FPDF()
        self.pdf.set_auto_page_break(auto=True, margin=15)
        
        # Set colors
        self.colors = {
            'critical': '#FF0000',
            'high': '#FF6B00',
            'medium': '#FFC100',
            'low': '#00B050',
            'info': '#2E75B6',
            'background': '#F2F2F2',
            'text': '#2D2D2D',
            'header': '#2E75B6'
        }
    
    def load_findings(self):
        """Load findings from JSON file"""
        try:
            with open(self.findings_file, 'r') as f:
                return json.load(f)
        except FileNotFoundError:
            return {"target": "Unknown", "findings": []}
    
    def load_strategy(self):
        """Load strategy document"""
        try:
            with open(self.strategy_file, 'r') as f:
                return f.read()
        except FileNotFoundError:
            return "No strategy document found."
    
    def load_poc_data(self):
        """Load proof of concept data"""
        try:
            with open(self.poc_file, 'r') as f:
                return f.read()
        except FileNotFoundError:
            return "No proof of concept data found."
    
    def load_ai_analysis(self):
        """Load AI analysis data"""
        ai_data = {}
        try:
            # Load anomaly detection results
            anomaly_file = os.path.join(self.ai_analysis_dir, "anomalies.txt")
            if os.path.exists(anomaly_file):
                with open(anomaly_file, 'r') as f:
                    ai_data['anomalies'] = f.read()
            
            # Load sensitive data findings
            sensitive_file = os.path.join(self.ai_analysis_dir, "sensitive_data.txt")
            if os.path.exists(sensitive_file):
                with open(sensitive_file, 'r') as f:
                    ai_data['sensitive_data'] = f.read()
            
            # Load final analysis
            final_analysis_file = os.path.join(self.ai_analysis_dir, "final_analysis.txt")
            if os.path.exists(final_analysis_file):
                with open(final_analysis_file, 'r') as f:
                    ai_data['final_analysis'] = f.read()
                    
        except FileNotFoundError:
            pass
            
        return ai_data
    
    def generate_severity_chart(self):
        """Generate severity distribution chart"""
        severities = {'Critical': 0, 'High': 0, 'Medium': 0, 'Low': 0, 'Info': 0}
        
        for finding in self.findings.get('findings', []):
            severity = finding.get('severity', 'Info').capitalize()
            if severity in severities:
                severities[severity] += 1
        
        # Create bar chart
        fig, ax = plt.subplots(figsize=(10, 6))
        colors = [self.colors['critical'], self.colors['high'], 
                 self.colors['medium'], self.colors['low'], self.colors['info']]
        
        bars = ax.bar(severities.keys(), severities.values(), color=colors)
        ax.set_title('Vulnerability Severity Distribution', fontsize=16, fontweight='bold')
        ax.set_ylabel('Count', fontweight='bold')
        
        # Add value labels on bars
        for bar in bars:
            height = bar.get_height()
            ax.text(bar.get_x() + bar.get_width()/2., height + 0.05,
                    f'{int(height)}', ha='center', va='bottom', fontweight='bold')
        
        plt.tight_layout()
        chart_path = os.path.join(self.workdir, "reports", "severity_chart.png")
        plt.savefig(chart_path, dpi=300, bbox_inches='tight')
        plt.close()
        
        return chart_path
    
    def generate_vulnerability_type_chart(self):
        """Generate vulnerability type distribution chart"""
        vuln_types = {}
        
        for finding in self.findings.get('findings', []):
            description = finding.get('description', '').lower()
            
            # Categorize vulnerabilities
            if 'sql' in description and 'injection' in description:
                vuln_types['SQL Injection'] = vuln_types.get('SQL Injection', 0) + 1
            elif 'xss' in description or 'cross-site' in description:
                vuln_types['XSS'] = vuln_types.get('XSS', 0) + 1
            elif 'csrf' in description or 'cross-site request forgery' in description:
                vuln_types['CSRF'] = vuln_types.get('CSRF', 0) + 1
            elif 'rce' in description or 'remote code execution' in description:
                vuln_types['RCE'] = vuln_types.get('RCE', 0) + 1
            elif 'lfi' in description or 'local file inclusion' in description:
                vuln_types['LFI'] = vuln_types.get('LFI', 0) + 1
            elif 'rfi' in description or 'remote file inclusion' in description:
                vuln_types['RFI'] = vuln_types.get('RFI', 0) + 1
            elif 'xxe' in description or 'xml external entity' in description:
                vuln_types['XXE'] = vuln_types.get('XXE', 0) + 1
            elif 'ssrf' in description or 'server side request forgery' in description:
                vuln_types['SSRF'] = vuln_types.get('SSRF', 0) + 1
            elif 'idor' in description or 'insecure direct object reference' in description:
                vuln_types['IDOR'] = vuln_types.get('IDOR', 0) + 1
            elif 'auth' in description or 'authentication' in description:
                vuln_types['Authentication'] = vuln_types.get('Authentication', 0) + 1
            else:
                vuln_types['Other'] = vuln_types.get('Other', 0) + 1
        
        # Create pie chart
        fig, ax = plt.subplots(figsize=(10, 8))
        colors = plt.cm.Set3(np.linspace(0, 1, len(vuln_types)))
        
        wedges, texts, autotexts = ax.pie(vuln_types.values(), labels=vuln_types.keys(), 
                                          autopct='%1.1f%%', colors=colors, startangle=90)
        
        ax.set_title('Vulnerability Type Distribution', fontsize=16, fontweight='bold')
        
        plt.setp(autotexts, size=10, weight='bold')
        plt.tight_layout()
        chart_path = os.path.join(self.workdir, "reports", "vuln_type_chart.png")
        plt.savefig(chart_path, dpi=300, bbox_inches='tight')
        plt.close()
        
        return chart_path
    
    def generate_timeline_chart(self):
        """Generate assessment timeline chart"""
        # This would normally come from log data, but we'll simulate it
        phases = [
            'Reconnaissance', 'Discovery', 'Vulnerability Assessment',
            'Exploitation', 'Post-Exploitation', 'Reporting'
        ]
        
        # Simulated time spent in each phase (hours)
        time_spent = [2.5, 1.8, 3.2, 2.0, 1.5, 1.0]
        
        fig, ax = plt.subplots(figsize=(12, 6))
        bars = ax.barh(phases, time_spent, color=self.colors['header'])
        ax.set_title('Assessment Timeline', fontsize=16, fontweight='bold')
        ax.set_xlabel('Time Spent (Hours)', fontweight='bold')
        
        # Add value labels on bars
        for bar in bars:
            width = bar.get_width()
            ax.text(width + 0.05, bar.get_y() + bar.get_height()/2.,
                    f'{width} hours', ha='left', va='center', fontweight='bold')
        
        plt.tight_layout()
        chart_path = os.path.join(self.workdir, "reports", "timeline_chart.png")
        plt.savefig(chart_path, dpi=300, bbox_inches='tight')
        plt.close()
        
        return chart_path
    
    def generate_word_cloud(self):
        """Generate word cloud from findings"""
        text = ""
        for finding in self.findings.get('findings', []):
            text += finding.get('description', '') + " "
        
        if not text.strip():
            text = "No significant findings detected during assessment"
        
        wordcloud = WordCloud(width=800, height=400, background_color='white',
                             colormap='viridis', max_words=50).generate(text)
        
        plt.figure(figsize=(10, 5))
        plt.imshow(wordcloud, interpolation='bilinear')
        plt.axis('off')
        plt.title('Finding Keywords Word Cloud', fontsize=16, fontweight='bold')
        
        chart_path = os.path.join(self.workdir, "reports", "wordcloud.png")
        plt.savefig(chart_path, dpi=300, bbox_inches='tight')
        plt.close()
        
        return chart_path
    
    def perform_ai_analysis(self):
        """Perform advanced AI analysis on findings"""
        analysis = {
            'risk_score': 0,
            'trends': [],
            'recommendations': [],
            'predictive_analysis': []
        }
        
        # Calculate risk score based on findings
        severity_weights = {'Critical': 10, 'High': 7, 'Medium': 4, 'Low': 2, 'Info': 1}
        total_weight = 0
        count = 0
        
        for finding in self.findings.get('findings', []):
            severity = finding.get('severity', 'Info').capitalize()
            if severity in severity_weights:
                total_weight += severity_weights[severity]
                count += 1
        
        if count > 0:
            analysis['risk_score'] = min(100, total_weight * 2)  # Scale to 100
        
        # Identify trends using simple text analysis
        descriptions = [f['description'].lower() for f in self.findings.get('findings', [])]
        
        if descriptions:
            # Use TF-IDF to find important terms
            vectorizer = TfidfVectorizer(stop_words='english', max_features=20)
            X = vectorizer.fit_transform(descriptions)
            terms = vectorizer.get_feature_names_out()
            
            # Simple clustering to find trends
            if len(descriptions) > 2:
                try:
                    kmeans = KMeans(n_clusters=min(3, len(descriptions)), random_state=42)
                    kmeans.fit(X.toarray())
                    
                    for i in range(kmeans.n_clusters):
                        cluster_terms = []
                        for j in range(len(terms)):
                            if kmeans.cluster_centers_[i][j] > 0.1:
                                cluster_terms.append(terms[j])
                        
                        if cluster_terms:
                            analysis['trends'].append(f"Trend {i+1}: {', '.join(cluster_terms[:5])}")
                except:
                    analysis['trends'].append("Insufficient data for trend analysis")
        
        # Generate recommendations based on findings
        if analysis['risk_score'] > 70:
            analysis['recommendations'].append("Immediate remediation required for critical vulnerabilities")
            analysis['recommendations'].append("Consider engaging a dedicated security team for emergency response")
        elif analysis['risk_score'] > 40:
            analysis['recommendations'].append("Prioritize remediation of high and critical severity vulnerabilities")
            analysis['recommendations'].append("Implement additional security monitoring")
        else:
            analysis['recommendations'].append("Maintain current security practices with regular assessments")
        
        # Add technology-specific recommendations
        tech_keywords = {
            'wordpress': "Ensure WordPress core, themes, and plugins are updated regularly",
            'api': "Implement API security best practices including rate limiting and authentication",
            'javascript': "Review client-side security controls and implement Content Security Policy",
            'sql': "Implement parameterized queries to prevent SQL injection attacks"
        }
        
        all_text = " ".join(descriptions)
        for tech, recommendation in tech_keywords.items():
            if tech in all_text:
                analysis['recommendations'].append(recommendation)
        
        # Predictive analysis
        if analysis['risk_score'] > 60:
            analysis['predictive_analysis'].append("High likelihood of successful exploitation based on current vulnerabilities")
            analysis['predictive_analysis'].append("Potential for data breach if vulnerabilities are not addressed promptly")
        else:
            analysis['predictive_analysis'].append("Low immediate risk, but continuous monitoring recommended")
        
        return analysis
    
    def create_pdf_report(self):
        """Create the PDF report"""
        # Generate charts
        severity_chart = self.generate_severity_chart()
        vuln_type_chart = self.generate_vulnerability_type_chart()
        timeline_chart = self.generate_timeline_chart()
        wordcloud = self.generate_word_cloud()
        
        # Perform AI analysis
        ai_analysis = self.perform_ai_analysis()
        
        # Add cover page
        self.pdf.add_page()
        self.pdf.set_fill_color(42, 117, 182)  # Blue background
        self.pdf.rect(0, 0, 210, 297, 'F')  # Cover background
        
        self.pdf.set_text_color(255, 255, 255)
        self.pdf.set_font('Arial', 'B', 24)
        self.pdf.cell(0, 60, '', 0, 1, 'C')
        self.pdf.cell(0, 20, 'SECURITY ASSESSMENT REPORT', 0, 1, 'C')
        
        self.pdf.set_font('Arial', 'B', 16)
        self.pdf.cell(0, 15, self.findings.get('target', 'Unknown Target'), 0, 1, 'C')
        
        self.pdf.set_font('Arial', '', 14)
        self.pdf.cell(0, 10, f'Date: {datetime.datetime.now().strftime("%Y-%m-%d")}', 0, 1, 'C')
        
        self.pdf.set_font('Arial', 'I', 12)
        self.pdf.cell(0, 10, 'Generated by AI-Powered Vulnersearch System', 0, 1, 'C')
        
        # Add table of contents
        self.pdf.add_page()
        self.pdf.set_text_color(0, 0, 0)
        self.pdf.set_font('Arial', 'B', 16)
        self.pdf.cell(0, 10, 'TABLE OF CONTENTS', 0, 1, 'C')
        self.pdf.ln(10)
        
        sections = [
            '1. Executive Summary',
            '2. Assessment Overview',
            '3. Vulnerability Analysis',
            '4. Detailed Findings',
            '5. AI-Powered Insights',
            '6. Recommendations',
            '7. Conclusion'
        ]
        
        self.pdf.set_font('Arial', '', 12)
        for section in sections:
            self.pdf.cell(0, 8, section, 0, 1)
            self.pdf.ln(2)
        
        # Executive Summary
        self.pdf.add_page()
        self.pdf.set_font('Arial', 'B', 16)
        self.pdf.cell(0, 10, '1. EXECUTIVE SUMMARY', 0, 1)
        self.pdf.ln(5)
        
        self.pdf.set_font('Arial', '', 12)
        exec_summary = f"""
This report presents the findings of a comprehensive security assessment conducted on {self.findings.get('target', 'the target system')}. 
The assessment was performed using advanced AI-powered tools and methodologies to identify potential vulnerabilities and security weaknesses.

Overall Risk Score: {ai_analysis['risk_score']}/100

Key Findings:
- Total vulnerabilities identified: {len(self.findings.get('findings', []))}
- Critical vulnerabilities: {sum(1 for f in self.findings.get('findings', []) if f.get('severity', '').lower() == 'critical')}
- High vulnerabilities: {sum(1 for f in self.findings.get('findings', []) if f.get('severity', '').lower() == 'high')}

The assessment revealed several security concerns that require attention. Immediate remediation is recommended for critical and high severity issues.
"""
        self.pdf.multi_cell(0, 8, exec_summary)
        
        # Assessment Overview
        self.pdf.add_page()
        self.pdf.set_font('Arial', 'B', 16)
        self.pdf.cell(0, 10, '2. ASSESSMENT OVERVIEW', 0, 1)
        self.pdf.ln(5)
        
        self.pdf.set_font('Arial', '', 12)
        overview = f"""
Assessment Target: {self.findings.get('target', 'Unknown')}
Assessment Date: {datetime.datetime.now().strftime('%Y-%m-%d')}
Assessment Methodology: AI-Powered Comprehensive Security Testing

The assessment employed a multi-faceted approach including:
- Automated vulnerability scanning
- AI-powered anomaly detection
- Manual verification of findings
- Advanced exploit testing

The assessment focused on identifying vulnerabilities across the entire attack surface, including web applications, network services, and infrastructure components.
"""
        self.pdf.multi_cell(0, 8, overview)
        
        # Add timeline chart
        self.pdf.image(timeline_chart, x=10, y=None, w=190)
        self.pdf.ln(100)
        
        # Vulnerability Analysis
        self.pdf.add_page()
        self.pdf.set_font('Arial', 'B', 16)
        self.pdf.cell(0, 10, '3. VULNERABILITY ANALYSIS', 0, 1)
        self.pdf.ln(5)
        
        # Add severity chart
        self.pdf.image(severity_chart, x=10, y=None, w=190)
        self.pdf.ln(100)
        
        # Add vulnerability type chart
        self.pdf.image(vuln_type_chart, x=10, y=None, w=190)
        self.pdf.ln(100)
        
        # Add word cloud
        self.pdf.image(wordcloud, x=10, y=None, w=190)
        self.pdf.ln(80)
        
        # Detailed Findings
        self.pdf.add_page()
        self.pdf.set_font('Arial', 'B', 16)
        self.pdf.cell(0, 10, '4. DETAILED FINDINGS', 0, 1)
        self.pdf.ln(5)
        
        findings = self.findings.get('findings', [])
        if not findings:
            self.pdf.set_font('Arial', '', 12)
            self.pdf.multi_cell(0, 8, "No significant vulnerabilities were identified during the assessment.")
        else:
            # Group findings by severity
            by_severity = {}
            for finding in findings:
                severity = finding.get('severity', 'Info').capitalize()
                if severity not in by_severity:
                    by_severity[severity] = []
                by_severity[severity].append(finding)
            
            # Output findings by severity (Critical first)
            for severity in ['Critical', 'High', 'Medium', 'Low', 'Info']:
                if severity in by_severity:
                    self.pdf.set_font('Arial', 'B', 14)
                    self.pdf.set_text_color(*self.hex_to_rgb(self.colors[severity.lower()]))
                    self.pdf.cell(0, 10, f'{severity} Severity Findings', 0, 1)
                    self.pdf.set_text_color(0, 0, 0)
                    
                    for i, finding in enumerate(by_severity[severity], 1):
                        self.pdf.set_font('Arial', 'B', 12)
                        self.pdf.cell(0, 8, f'{i}. {finding.get("description", "No description")}', 0, 1)
                        self.pdf.set_font('Arial', '', 10)
                        self.pdf.multi_cell(0, 6, f'Target: {finding.get("target", "Unknown")}')
                        self.pdf.ln(2)
                    
                    self.pdf.ln(5)
        
        # AI-Powered Insights
        self.pdf.add_page()
        self.pdf.set_font('Arial', 'B', 16)
        self.pdf.cell(0, 10, '5. AI-POWERED INSIGHTS', 0, 1)
        self.pdf.ln(5)
        
        self.pdf.set_font('Arial', '', 12)
        self.pdf.multi_cell(0, 8, "Advanced AI analysis was performed on the assessment findings to identify patterns, trends, and potential risks that may not be immediately apparent through traditional analysis methods.")
        self.pdf.ln(5)
        
        self.pdf.set_font('Arial', 'B', 14)
        self.pdf.cell(0, 8, 'Risk Assessment:', 0, 1)
        self.pdf.set_font('Arial', '', 12)
        self.pdf.multi_cell(0, 8, f"The overall risk score for the target system is {ai_analysis['risk_score']}/100. This score is based on the severity and quantity of vulnerabilities identified during the assessment.")
        self.pdf.ln(5)
        
        self.pdf.set_font('Arial', 'B', 14)
        self.pdf.cell(0, 8, 'Trend Analysis:', 0, 1)
        self.pdf.set_font('Arial', '', 12)
        for trend in ai_analysis['trends']:
            self.pdf.multi_cell(0, 8, f"- {trend}")
        self.pdf.ln(5)
        
        self.pdf.set_font('Arial', 'B', 14)
        self.pdf.cell(0, 8, 'Predictive Analysis:', 0, 1)
        self.pdf.set_font('Arial', '', 12)
        for prediction in ai_analysis['predictive_analysis']:
            self.pdf.multi_cell(0, 8, f"- {prediction}")
        
        # Recommendations
        self.pdf.add_page()
        self.pdf.set_font('Arial', 'B', 16)
        self.pdf.cell(0, 10, '6. RECOMMENDATIONS', 0, 1)
        self.pdf.ln(5)
        
        self.pdf.set_font('Arial', '', 12)
        self.pdf.multi_cell(0, 8, "Based on the findings of this assessment, the following recommendations are provided to improve the security posture of the target system:")
        self.pdf.ln(5)
        
        for i, recommendation in enumerate(ai_analysis['recommendations'], 1):
            self.pdf.set_font('Arial', 'B', 12)
            self.pdf.cell(0, 8, f'{i}.', 0, 0)
            self.pdf.set_font('Arial', '', 12)
            self.pdf.multi_cell(0, 8, f' {recommendation}')
            self.pdf.ln(2)
        
        # Remediation priority table
        self.pdf.ln(10)
        self.pdf.set_font('Arial', 'B', 14)
        self.pdf.cell(0, 8, 'Remediation Priority Guide', 0, 1)
        self.pdf.ln(5)
        
        # Create a simple table
        self.pdf.set_font('Arial', 'B', 12)
        self.pdf.cell(40, 8, 'Priority', 1, 0, 'C')
        self.pdf.cell(150, 8, 'Action', 1, 1, 'C')
        
        priorities = [
            ('Immediate', 'Address critical vulnerabilities within 24 hours'),
            ('High', 'Address high severity vulnerabilities within 7 days'),
            ('Medium', 'Address medium severity vulnerabilities within 30 days'),
            ('Low', 'Address low severity vulnerabilities in next update cycle')
        ]
        
        self.pdf.set_font('Arial', '', 10)
        for priority, action in priorities:
            self.pdf.cell(40, 8, priority, 1, 0, 'C')
            self.pdf.cell(150, 8, action, 1, 1)
        
        # Conclusion
        self.pdf.add_page()
        self.pdf.set_font('Arial', 'B', 16)
        self.pdf.cell(0, 10, '7. CONCLUSION', 0, 1)
        self.pdf.ln(5)
        
        self.pdf.set_font('Arial', '', 12)
        conclusion = f"""
This security assessment of {self.findings.get('target', 'the target system')} has identified several areas requiring attention to ensure the security and integrity of the system.

The AI-powered analysis indicates a {'high' if ai_analysis['risk_score'] > 70 else 'moderate' if ai_analysis['risk_score'] > 40 else 'low'} overall risk level. 
It is recommended that the findings and recommendations outlined in this report be addressed in accordance with the remediation priority guide.

Regular security assessments should be conducted to ensure that new vulnerabilities are identified and addressed promptly. Continuous monitoring and improvement of security controls is essential to maintain a strong security posture.
"""
        self.pdf.multi_cell(0, 8, conclusion)
        
        # Save the PDF
        self.pdf.output(self.output_file)
        return self.output_file
    
    def hex_to_rgb(self, hex_color):
        """Convert hex color to RGB tuple"""
        hex_color = hex_color.lstrip('#')
        return tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))
    
    def generate_html_report(self):
        """Generate an HTML version of the report"""
        # This would create a complementary HTML report
        # Implementation would be similar to PDF generation but in HTML format
        pass
    
    def generate_executive_dashboard(self):
        """Generate an executive dashboard with key metrics"""
        # This would create a separate dashboard view
        pass

def main():
    parser = argparse.ArgumentParser(description='AI-Powered Security Assessment Report Generator')
    parser.add_argument('workdir', help='Working directory containing assessment results')
    parser.add_argument('-o', '--output', help='Output file path (default: workdir/reports/security_assessment_report.pdf)')
    parser.add_argument('--html', action='store_true', help='Generate HTML report in addition to PDF')
    parser.add_argument('--dashboard', action='store_true', help='Generate executive dashboard')
    
    args = parser.parse_args()
    
    if not os.path.exists(args.workdir):
        print(f"Error: Directory {args.workdir} does not exist.")
        sys.exit(1)
    
    # Generate the report
    generator = AIReportGenerator(args.workdir, args.output)
    report_path = generator.create_pdf_report()
    
    print(f"Report generated successfully: {report_path}")
    
    # Generate additional formats if requested
    if args.html:
        generator.generate_html_report()
        print("HTML report generated.")
    
    if args.dashboard:
        generator.generate_executive_dashboard()
        print("Executive dashboard generated.")

if __name__ == '__main__':
    main()
